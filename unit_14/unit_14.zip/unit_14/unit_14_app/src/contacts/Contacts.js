import React from 'react';

class Contacts extends React.Component {
    render() {
        return (
            <div className="Contacts">
                <h1>Contacts</h1>
            </div>
        );
    }
}

export default Contacts;

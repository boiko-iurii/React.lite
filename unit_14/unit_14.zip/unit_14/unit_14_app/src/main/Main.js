import React from 'react';

class Main extends React.Component {
    render() {
        return (
            <div className="Main">
                <h1>Main</h1>
            </div>
        );
    }
}

export default Main;

import React from 'react';

class About extends React.Component {
    render() {
        return (
            <div className="About">
                <h1>About</h1>
            </div>
        );
    }
}

export default About;

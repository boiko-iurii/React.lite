import React from 'react';

class ErrorPage extends React.Component {
    render() {
        return (
            <div className="Error">
                <h1>ErrorPage</h1>
            </div>
        );
    }
}

export default ErrorPage;

import React from 'react';
import './Footer.css';

class Footer extends React.Component {
    render() {
        return (
            <div className="site-footer">
                Site Footer
            </div>
        );
    }
}

export default Footer;

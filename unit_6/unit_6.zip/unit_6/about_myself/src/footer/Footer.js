import React from 'react';
import './Footer.css';


class Footer extends React.Component {
    render() {
        return (
            <footer className="app-footer">

                <p style={{ textAlign: 'center', margin: 0 }}>&copy; Copyrights. 2020</p>

            </footer>
        );
    }
}

export default Footer;
